//
//  SampleTableView.m
//  WebServiceExample
//
//  Created by Jean Martin on 02/07/18.
//  Copyright © 2018 Public. All rights reserved.
//

#import "SampleTableView.h"
#import "WebServiceCalling.h"
#import "Utils.h"
#import "TableViewCell.h"

@interface SampleTableView ()

@end

@implementation SampleTableView
@synthesize responseContact,responseDictionary;

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES];
    
    responseDictionary = [[NSDictionary alloc] init];
    responseContact = [[NSMutableArray alloc] init];
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    
    [self serviceDisplay];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return responseContact.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    TableViewCell * cellTableView = (TableViewCell *) [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    
    // Name
    NSString *name = [[responseContact valueForKey:@"name"] objectAtIndex:indexPath.row];
    cellTableView.nameLabelOutlet.text = name;
    
    // Email
    NSString *email = [[responseContact valueForKey:@"email"]objectAtIndex:indexPath.row];
    cellTableView.emailLabelOutlet.text = email;
    
    // Address
//    NSString *homePhone = [[responseContact valueForKeyPath:@"phone.mobile"]objectAtIndex:indexPath.row];
//    cellTableView.phoneLabelOutlet.text = homePhone;
    
    NSString *homePhone = [NSString stringWithFormat:@"%@ , %@ , %@",
                            [[responseContact valueForKeyPath:@"phone.office"]objectAtIndex:indexPath.row],
                            [[responseContact valueForKeyPath:@"phone.mobile"]objectAtIndex:indexPath.row],
                            [[responseContact valueForKeyPath:@"phone.home"]objectAtIndex:indexPath.row]];
    cellTableView.phoneLabelOutlet.text = homePhone;
    
    return cellTableView;
}

-(void)serviceDisplay{
    
    NSString *urlString = [NSString stringWithFormat:@"https://api.androidhive.info/contacts/"];
    NSURL *url = [NSURL URLWithString:urlString];
    responseDictionary = [WebServiceCalling connection:url];
    
    if([Utils isReachable]){
        
        if(responseDictionary != nil){
            
            NSArray *resArray = [responseDictionary valueForKey:@"contacts"];
            for (int i = 0; i < [resArray count]; i++){

                NSObject *sampObj = [resArray objectAtIndex:i];
                NSLog(@"samp Obj**%@",sampObj);
                [responseContact addObject:sampObj];
                
            }
        }else{
            NSLog(@"Dictionary is empty");
        }
    }
}
@end
