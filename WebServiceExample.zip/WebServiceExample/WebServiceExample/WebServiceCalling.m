//
//  WebServiceCalling.m
//  WebServiceExample
//
//  Created by Jean Martin on 02/07/18.
//  Copyright © 2018 Public. All rights reserved.
//

#import "WebServiceCalling.h"
#import <AFNetworking.h>

@implementation WebServiceCalling

+(NSDictionary *)connection:(NSURL *)url{
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url];
    AFHTTPRequestOperation *operationRequest = [[AFHTTPRequestOperation alloc]initWithRequest:urlRequest];
    operationRequest.responseSerializer=[AFJSONResponseSerializer serializer];
    operationRequest.responseSerializer.acceptableContentTypes=[NSSet setWithObjects:@"text/html",@"application/json",nil];
    operationRequest.securityPolicy.allowInvalidCertificates = YES;
    operationRequest.securityPolicy.validatesDomainName = NO;
    [operationRequest setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation,id responseObject)
     {
                  NSLog(@"JSON  :%@",responseObject);
     }
    failure:^(AFHTTPRequestOperation *operation, NSError *error)
     {
                  NSLog(@"Response Error in Call:%@",error);
     }];
    operationRequest.securityPolicy.allowInvalidCertificates = YES;
    [operationRequest start];
    [operationRequest waitUntilFinished];
    return operationRequest.responseObject;
}

@end
