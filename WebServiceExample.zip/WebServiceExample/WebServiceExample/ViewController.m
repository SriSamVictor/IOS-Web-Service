//
//  ViewController.m
//  WebServiceExample
//
//  Created by Jean Martin on 02/07/18.
//  Copyright © 2018 Public. All rights reserved.
//

#import "ViewController.h"
#import "WebServiceCalling.h"
#import <SVProgressHUD.h>
#import "Utils.h"
#import "SampleTableView.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize responseDictionary,cityLabelOutlet,textDisplayOutlet,nameLabelOutlet,emailLabelOutlet,addressLabelOutlet,phoneLabelOutelt,responseSubDictionary;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self.navigationController setNavigationBarHidden:YES];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)serviceCallling{
    
    [SVProgressHUD showWithStatus:@"Loading...."];
    NSString *urlString = [NSString stringWithFormat:@"https://api.androidhive.info/contacts/"];
    NSURL *url = [NSURL URLWithString:urlString];
    responseDictionary = [[NSDictionary alloc]init];
    responseDictionary = [WebServiceCalling connection:url];
    
    if([Utils isReachable]){
        
        if(responseDictionary != nil){
            
            NSDictionary *responseArray = [responseDictionary valueForKey:@"contacts"];
            NSLog(@"reponseDict**%@",responseArray);
            
            NSArray *strName = [responseArray valueForKey:@"name"];
            NSString *name = [strName objectAtIndex:0];
            
            NSArray *email = [responseArray valueForKey:@"email"];
            NSString *emailStr = [email objectAtIndex:0];
            
            NSArray *address = [responseArray valueForKey:@"address"];
            NSString *addressStr = [address objectAtIndex:0];
            
            NSArray *gender = [responseArray valueForKey:@"gender"];
            NSString *genderStr = [gender objectAtIndex:0];
            
            NSDictionary *phoneArray = [responseArray valueForKey:@"phone"];
            NSLog(@"Phone Array***%@",phoneArray);
            
            NSArray *phoneHome = [phoneArray valueForKey:@"home"];
            NSLog(@"Phone Home***%@",phoneHome);
            
            NSArray *phoneMobile = [phoneArray valueForKey:@"mobile"];
            NSLog(@"Phone Mobile**%@",phoneMobile);
            
            NSString *phoneHomeIndex = [phoneHome objectAtIndex:0];
            NSLog(@"Phone Home Index***%@",phoneHomeIndex);
            
            NSString *phoneMobileIndex = [phoneMobile objectAtIndex:0];
            NSLog(@"Phone Mobile Index%@",phoneMobileIndex);
            
            dispatch_async(dispatch_get_main_queue(), ^{
                    [SVProgressHUD dismiss];
            });
            
            textDisplayOutlet.text = name;
            emailLabelOutlet.text = emailStr;
            addressLabelOutlet.text = addressStr;
            cityLabelOutlet.text = genderStr;
            
            nameLabelOutlet.text = phoneMobileIndex;
            phoneLabelOutelt.text = phoneHomeIndex;
            
            
        }else{
            NSLog(@"Your Dictionary is empty");
        }
    }
}

- (IBAction)hitButton:(id)sender {
    
    [self serviceCallling];
    
}
- (IBAction)nextPageButtonAction:(id)sender {
    
    SampleTableView *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"SampleTableView"];
   [self.navigationController pushViewController:secondViewController animated:YES];
    
}
@end
