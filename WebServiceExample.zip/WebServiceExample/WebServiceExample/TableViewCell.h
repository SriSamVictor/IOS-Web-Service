//
//  TableViewCell.h
//  WebServiceExample
//
//  Created by Jean Martin on 02/07/18.
//  Copyright © 2018 Public. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *nameLabelOutlet;
@property (weak, nonatomic) IBOutlet UILabel *emailLabelOutlet;
@property (weak, nonatomic) IBOutlet UILabel *phoneLabelOutlet;
@end
