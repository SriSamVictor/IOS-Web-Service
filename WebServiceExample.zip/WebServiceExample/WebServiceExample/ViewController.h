//
//  ViewController.h
//  WebServiceExample
//
//  Created by Jean Martin on 02/07/18.
//  Copyright © 2018 Public. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)hitButton:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *textDisplayOutlet;
@property (weak, nonatomic) IBOutlet UILabel *nameLabelOutlet;
@property (weak, nonatomic) IBOutlet UILabel *phoneLabelOutelt;
@property (weak, nonatomic) IBOutlet UILabel *addressLabelOutlet;
@property (weak, nonatomic) IBOutlet UILabel *cityLabelOutlet;
@property (weak, nonatomic) IBOutlet UILabel *emailLabelOutlet;
- (IBAction)nextPageButtonAction:(id)sender;

@property(strong, nonatomic)NSDictionary *responseDictionary;
@property(strong, nonatomic)NSDictionary *responseSubDictionary;

@end

