//
//  Utils.m
//  WebServiceExample
//
//  Created by Jean Martin on 02/07/18.
//  Copyright © 2018 Public. All rights reserved.
//

#import "Utils.h"

@implementation Utils

+(BOOL)isReachable{
    BOOL isReachable = YES;
    return isReachable;
}

@end
