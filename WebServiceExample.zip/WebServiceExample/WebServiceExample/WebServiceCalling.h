//
//  WebServiceCalling.h
//  WebServiceExample
//
//  Created by Jean Martin on 02/07/18.
//  Copyright © 2018 Public. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WebServiceCalling : NSObject
+(NSDictionary *)connection:(NSURL *)url;
@end
