//
//  SampleTableView.h
//  WebServiceExample
//
//  Created by Jean Martin on 02/07/18.
//  Copyright © 2018 Public. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SampleTableView : UIViewController<UITableViewDelegate,UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITableView *sampleTableViewOutlet;
@property (strong, nonatomic)NSDictionary *responseDictionary;
@property (strong,nonatomic)NSMutableArray *responseContact;

@end
